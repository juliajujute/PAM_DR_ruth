import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Nome {
   nome!:string

  constructor(){}
    setNome(value:string){
      this.nome=value;
    }
  
}
