import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Inicio {
   inicio!:string;

  constructor(){}
    setInicio(value:string){
      this.inicio=value;
    }
  
}
