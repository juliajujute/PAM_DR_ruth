import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Valorm {
   valorm!:number

  constructor(){}
    setValorm(value:number){
      this.valorm = value;
    }
  
}
