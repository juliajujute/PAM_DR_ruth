import { TestBed } from '@angular/core/testing';

import { Duracao } from './duracao';

describe('Duracao', () => {
  let service: Duracao;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Duracao);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
