import { TestBed } from '@angular/core/testing';

import { Valorm } from './valorm';

describe('Valorm', () => {
  let service: Valorm;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Valorm);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
