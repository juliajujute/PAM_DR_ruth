import { Injectable } from '@angular/core';
import { Inicio } from '../services/inicio';
import { Nome } from '../services/nome';
import { Duracao } from '../services/duracao';
import { Valorm } from '../services/valorm';

@Injectable({
  providedIn: 'root',
})
export class Curso {
  cadcurso!:string
  lista:string="<b>Lista</b><br>"
  constructor(
    private nome:Nome,
    private inicio:Inicio,
    private duracao:Duracao,
    private valorm:Valorm

  ){}
  pedirNome(cadcurso: string, item: string){
    this.cadcurso=cadcurso
    this.nome.setNome(item)
    this.lista+=this.cadcurso+'Nome do Curso: '+this.nome.nome+'<br>'
  }
  pedirInicio(cadcurso: string, item: string){
    this.cadcurso=cadcurso
    this.inicio.setInicio(item)
    this.lista+=this.cadcurso+'Início: '+this.inicio.inicio+'<br>'
  }
  pedirDuracao(cadcurso: string, item: string){
    this.cadcurso=cadcurso
    this.duracao.setDuracao(item)
    this.lista+=this.cadcurso+'Duração: '+this.duracao.duracao+'<br>'
  }
  pedirValorm(cadcurso: string, item: number){
    this.cadcurso=cadcurso
    this.valorm.setValorm(item)
    this.lista+=this.cadcurso+'Valor Mensal: '+this.valorm.valorm+'<br><br>'
  }
 
  
  
  
}
