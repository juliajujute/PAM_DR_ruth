import { Component, OnInit } from '@angular/core';
import { Curso } from '../providers/curso';

@Component({
  selector: 'app-cad-curso',
  templateUrl: './cad-curso.page.html',
  styleUrls: ['./cad-curso.page.scss'],
  standalone : false
})
export class CadCursoPage implements OnInit {
  lista:string=''
  item1:string=''
  item2:string=''
  item3:string=''
  item4:number = 0
  cadcurso:string=""

  constructor(private curso:Curso) { }
  
  trocarCurso(value:string){
    this.cadcurso=value
  }
armazenarItem(){
  let valorExibicao: any;
  if (this.item4 === 0 || this.item4 === null){ 
    valorExibicao = "Gratuito";
  }else {
    valorExibicao = "R$ " + this.item4;
  }
    this.curso.pedirNome(this.cadcurso, this.item1)
    this.curso.pedirInicio(this.cadcurso, this.item2)
    this.curso.pedirDuracao(this.cadcurso, this.item3)
    this.curso.pedirValorm(this.cadcurso, valorExibicao);
    this.lista=this.curso.lista
    
  }

  ngOnInit() {
  }

}
