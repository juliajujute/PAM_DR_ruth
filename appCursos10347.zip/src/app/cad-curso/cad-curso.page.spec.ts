import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CadCursoPage } from './cad-curso.page';

describe('CadCursoPage', () => {
  let component: CadCursoPage;
  let fixture: ComponentFixture<CadCursoPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CadCursoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
