import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CadCursoPageRoutingModule } from './cad-curso-routing.module';

import { CadCursoPage } from './cad-curso.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CadCursoPageRoutingModule
  ],
  declarations: [CadCursoPage]
})
export class CadCursoPageModule {}
