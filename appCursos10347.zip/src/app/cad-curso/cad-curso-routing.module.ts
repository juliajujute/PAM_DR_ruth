import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CadCursoPage } from './cad-curso.page';

const routes: Routes = [
  {
    path: '',
    component: CadCursoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CadCursoPageRoutingModule {}
